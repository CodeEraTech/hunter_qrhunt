<?php
declare(strict_types=1);

require dirname(__DIR__) . '/_bootstrap.php';
require_post();

$user = api_user();
$key = trim((string)($_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? ''));
$d = json_input();

try {
    $r = wallet_checkout(
        (int)$user['id'],
        trim((string)($d['bill_amount'] ?? '')),
        (int)($d['merchant_id'] ?? 0) ?: null,
        $key,
        isset($d['coupon_code']) ? (string)$d['coupon_code'] : null,
        isset($d['grant_id']) ? (string)$d['grant_id'] : null,
        isset($d['product_id']) ? (string)$d['product_id'] : null,
        isset($d['category_id']) ? (string)$d['category_id'] : null
    );
    json_response(true, 'Checkout completed with promo, bonus, coupon, then real-cash priority', $r, $r['created'] ? 201 : 200);
} catch (InvalidArgumentException $e) {
    json_response(false, $e->getMessage(), null, 422);
} catch (RuntimeException $e) {
    json_response(false, $e->getMessage(), null, 409);
}
